declare module 'mfe1/Component';
declare module 'mfe1/Module';